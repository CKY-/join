const { ChatClient } = require("@twurple/chat");
const fs = require("node:fs");

module.exports = {
  getScriptManifest: () => {
    return {
      name: "Chat Join Logger",
      description: "Adds chater Join to the logs",
      author: "cky",
      version: "1.0",
      firebotVersion: "5",
      startupOnly: true
    };
  },

  getDefaultParameters: () => {
    return {
      file: {
        title: "File",
        type: "filepath",
        default: "c:\\temp\\FirebotLog.txt",
        description: "where to store the logged messages"
      }
    };
  },

  run: ({ parameters, modules, firebot }) => {
    const { logger } = modules;
    const chat = new ChatClient({
      channels: [firebot.accounts.streamer.username],
      requestMembershipEvents: true
    });

    chat.onJoin((...evt) => {
      if (evt[1].includes("justinfan")) {
        return;
      }
      let date = new Date();
      fs.writeFile(parameters.file, `[${date}]Join: ${evt[1]}\n`, { flag: "a+" },(err) => {
          if (err) {
             modules.logger.error(err);
          } else {
            // file written successfully
          }
        }
      );
    });

    chat.onPart((...evt) => {
      if (evt[1].includes("justinfan")) {
        return;
      }
      let date = new Date();
      fs.writeFile(parameters.file, `[${date}]Part: ${evt[1]}\n`, { flag: "a+" }, (err) => {
          if (err) {
             modules.logger.error(err);
          } else {
            // file written successfully
          }
        }
      );
    });
  }
};
